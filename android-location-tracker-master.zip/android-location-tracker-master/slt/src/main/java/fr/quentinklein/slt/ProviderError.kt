package fr.quentinklein.slt

class ProviderError(detailMessage: String?) : Throwable(detailMessage)